## Measure Summary

| Measure | Purpose |
| --- | --- |
| **Gross Sales** | Original sales value before discounts and refunds |
| **Net Sales** | Sales retained after commercial deductions |
| **Contribution Revenue** | Revenue available to cover product and operating costs |
| **Contribution Margin** | Value remaining after variable costs |
| **Contribution Margin %** | Margin efficiency relative to contribution revenue |
| **Product Cost Rate** | Share of gross sales absorbed by product cost |
| **Return Loss** | Financial impact associated with returned orders |
| **Lost Sales Value** | Revenue opportunity lost through unfulfilled demand |
| **Acquisition Cost / New Customer** | Cost required to acquire each new customer |
| **Repeat Contribution Margin** | Margin generated after the customer's acquisition period |

---

## 1. Gross Sales

Calculates the original value of ordered sales before discounts, refunds, and other deductions.

```DAX
Gross Sales =
SUM (
    'Fact Order Lines'[Gross Sales]
)
```

## 2. Net Sales

Calculates sales retained after discounts and refunds.

```DAX
Net Sales =
SUM (
    'Fact Order Lines'[Net Sales]
)
```

## 3. Contribution Revenue

Calculates the revenue available to cover product and variable operating costs.

```DAX
Contribution Revenue =
SUM (
    'Fact Order Lines'[Contribution Revenue]
)
```

In the profitability bridge, Contribution Revenue reconciles to:

```text
Net Sales + Shipping Revenue
```

## 4. Contribution Margin

Calculates the value remaining after product and variable operating costs.

```DAX
Contribution Margin =
SUM (
    'Fact Order Lines'[Contribution Margin]
)
```

The profitability bridge reconciles this measure as:

```text
Contribution Revenue - Product Cost - Variable Operating Cost
```

## 5. Contribution Margin %

Calculates the proportion of Contribution Revenue retained as Contribution Margin.

```DAX
Contribution Margin % =
DIVIDE (
    [Contribution Margin],
    [Contribution Revenue],
    0
)
```

## 6. Product Cost Rate

Calculates the proportion of Gross Sales absorbed by product cost.

```DAX
Product Cost Rate =
DIVIDE (
    SUM ( 'Fact Order Lines'[Product Cost] ),
    [Gross Sales],
    0
)
```

## 7. Return Loss

Calculates the total financial loss associated with returned orders.

```DAX
Return Loss =
SUM (
    'Fact Order Lines'[Return Loss]
)
```

This is used as a diagnostic leakage measure by return reason and product hierarchy.

## 8. Lost Sales Value

Calculates the value of demand that could not be fulfilled because of stock availability.

```DAX
Lost Sales Value =
SUM (
    'Fact Order Lines'[Lost Sales Value]
)
```

## 9. Acquisition Cost / New Customer

Calculates acquisition-period marketing cost per newly acquired customer. Customers are treated as new when the transaction falls within their acquisition period (`Months Since First Purchase = 0`).

```DAX
Acquisition Cost / New Customer =
VAR AcquisitionCost =
    CALCULATE (
        SUM ( 'Fact Order Lines'[Allocated Marketing Cost] ),
        'Cohort Age'[Months Since First Purchase] = 0
    )
VAR NewCustomers =
    CALCULATE (
        DISTINCTCOUNT ( 'Fact Order Lines'[Customer Key] ),
        'Cohort Age'[Months Since First Purchase] = 0
    )
RETURN
    DIVIDE (
        AcquisitionCost,
        NewCustomers,
        0
    )
```

## 10. Repeat Contribution Margin

Calculates Contribution Margin generated after the customer's acquisition period.

```DAX
Repeat Contribution Margin =
CALCULATE (
    [Contribution Margin],
    'Cohort Age'[Months Since First Purchase] > 0
)
```

---

# Supporting Measures

## Repeat CM Share %

Calculates the share of total Contribution Margin generated after acquisition.

```DAX
Repeat CM Share % =
DIVIDE (
    [Repeat Contribution Margin],
    [Contribution Margin],
    0
)
```

## Company CM% Baseline

Removes the current geography filter to calculate the company-wide Contribution Margin % benchmark used in regional comparison visuals.

```DAX
Company CM% Baseline =
CALCULATE (
    [Contribution Margin %],
    ALL ( 'Geography' )
)
```

## CM% Variance vs Baseline

Shows how the current geography performs relative to the company-wide margin benchmark.

```DAX
CM% Variance vs Baseline =
[Contribution Margin %] - [Company CM% Baseline]
```

---
